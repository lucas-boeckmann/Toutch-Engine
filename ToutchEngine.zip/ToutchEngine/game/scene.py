from toolkit.non_voxel.model_renderer import obj_model
from objects.voxel_pointer import VoxelMarker
from game.world import World
from game.config import *

class scene:
    def __init__(self, app):
        self.app = app
        self.world = World(self.app)
        self.voxel_marker = VoxelMarker(self.world.voxel_handler)
        #self.fish = obj_model("objects/fish/fish.obj", app)

    def update(self):
        self.world.update()
        self.voxel_marker.update()

    def render(self):
        self.world.render()
        self.voxel_marker.render()
        #self.fish.render()