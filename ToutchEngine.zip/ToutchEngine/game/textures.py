import pygame as pg
import moderngl as mgl
from toolkit.texture_loader import *

class Textures:
    def __init__ (self, app):
        self.app = app
        self.context = app.context

        #load
        self.texture_0 = load(app,'frame.png')
        self.sprite_sheet_0 = load(app,"textures-out.png", is_sprite_sheet=True)
        
        #assign texture unit
        self.texture_0.use(location=0)
        self.sprite_sheet_0.use(location=1)

