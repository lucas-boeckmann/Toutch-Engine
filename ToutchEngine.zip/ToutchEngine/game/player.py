from objects.camera import Camera
from game.config import *
import pygame as pg

class player(Camera):
    def __init__(self, app, position=PLAYER_POSITION, yaw=-90, pitch=0):
        self.app = app
        super().__init__(position, yaw, pitch)

    def update(self):
        self.keyboard_control()
        self.mouse_control()
        super().update()

    def handle_event(self, event):
        #add/remove voxels with mouse
        if event.type == pg.MOUSEBUTTONDOWN:
            voxel_handler = self.app.scene.world.voxel_handler
            if event.button == 1:
                voxel_handler.remove_voxel()
            elif event.button == 3:
                voxel_handler.add_voxel()

    def mouse_control(self):
        mouse_dx, mouse_dy = pg.mouse.get_rel()
        if mouse_dx:
            self.rotate_yaw(delta_x=mouse_dx * MOUSE_SENSIVITY)
        if mouse_dy:
            self.rotate_pitch(delta_y=mouse_dy * MOUSE_SENSIVITY)

    def keyboard_control(self):
        key_state = pg.key.get_pressed()
        speed = PLAYER_SPEED * self.app.delta_time

        if key_state[pg.K_w]:
            self.move_forward(speed)
        if key_state[pg.K_s]:
            self.move_back(speed)
        if key_state[pg.K_a]:
            self.move_left(speed)
        if key_state[pg.K_d]:
            self.move_right(speed)
        if key_state[pg.K_SPACE]:
            self.move_up(speed)
        if key_state[pg.K_LCTRL]:
            self.move_down(speed)
