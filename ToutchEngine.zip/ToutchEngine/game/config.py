from numba import njit
import pygame as pg
import numpy as np
import math
import glm


pg.init()
#general config
SCREEN_WIDTH = pg.display.Info().current_w
SCREEN_HEIGHT = pg.display.Info().current_h
WIN_RES =  glm.vec2(SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2)
START_FULLSCREEN = True
LOCK_MOUSE = True
RENDER_DISTANCE = 20

#raycasting config
MAX_RAY_DIST = 8

#camera config
ASPECT_RATIO = WIN_RES.x / WIN_RES.y
FOV_DEG = 50
V_FOV = glm.radians(FOV_DEG)
H_FOV = 2 * math.atan(math.tan(V_FOV * 0.5) * ASPECT_RATIO)
NEAR = 0.1
FAR = 2000.0
PITCH_MAX = glm.radians(89)

#world generation
SEED = 20
SCALE = 1

#chunk config
CHUNK_SIZE = 48
H_CHUNK_SIZE = CHUNK_SIZE // 2
CHUNK_AREA = CHUNK_SIZE * CHUNK_SIZE
CHUNK_VOL = CHUNK_AREA * CHUNK_SIZE
CHUNK_SPHERE_RADIUS = H_CHUNK_SIZE * math.sqrt(3)

#world config
WORLD_W, WORLD_H = 20, 2
WORLD_D = WORLD_W
WORLD_AREA = WORLD_W * WORLD_D
WORLD_VOL = WORLD_AREA * WORLD_H

#world center
CENTER_XZ = WORLD_H * H_CHUNK_SIZE
CENTER_Y = WORLD_H * H_CHUNK_SIZE

#player config
PLAYER_SPEED = 0.01
PLAYER_ROT_SPEED = 0.003
PLAYER_POSITION = glm.vec3(CENTER_XZ, WORLD_H * CHUNK_SIZE, CENTER_XZ)
MOUSE_SENSIVITY = 0.002

#color config
BLACK = (0, 0, 0)
DARKGRAY = (0.33, 0.33, 0.33)
GRAY = (0.5, 0.5, 0.5)
LIGHTGRAY = (0.5, 0.5, 0.5)
WHITE = (1, 1, 1)

RED = (1, 0, 0)
GREEN = (0, 1, 0)
BLUE = (0, 0, 1)

DARKMIDNIGHTBLUE = (0, 0.2, 0.4)
SKYBLUE = (0.529, 0.807, 0.921)

BACKGROUND_COLOR = SKYBLUE

#textures
AIR = 0
GRASS = 1
DIRT = 2
GRAVEL = 3
SNOW = 4
LEAVES = 5
WOOD = 6
SAND = 7
STONE = 8

#material levels
SNOW_LVL = 56
STONE_LVL = 50
DIRT_LVL = 40
GRASS_LVL = 8
GRAVEL_LVL = 7
SAND_LVL = 6

#tree config
TREE_PROBABILITY = 0.01
TREE_WIDTH, TREE_HEIGHT = 8, 16
TREE_H_WIDTH, TREE_H_HEIGHT = TREE_WIDTH // 2, TREE_HEIGHT // 2

#water config
WATER_AREA = 5 * CHUNK_SIZE * WORLD_W
WATER_LEVEL = 5.6
