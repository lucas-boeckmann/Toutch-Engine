#engine based on https://github.com/StanislavPetrovV/Minecraft

from shader_manager import shader_manager
from game.textures import Textures
#=============================#
#   GAME FILES LOADED HERE    #
from game.player import player#
from game.scene import scene  #
from game.config import *     #
#=============================#
import moderngl as mgl
import pygame as pg
import sys

class ToutchEngine:
    def __init__(self):
        #initial setup
        pg.init()
        pg.display.gl_set_attribute(pg.GL_CONTEXT_MAJOR_VERSION, 3)
        pg.display.gl_set_attribute(pg.GL_CONTEXT_MINOR_VERSION, 3)
        pg.display.gl_set_attribute(pg.GL_CONTEXT_PROFILE_MASK, pg.GL_CONTEXT_PROFILE_CORE)
        pg.display.gl_set_attribute(pg.GL_DEPTH_SIZE, 24)
        
        self.fullscreen = START_FULLSCREEN
        if self.fullscreen:
            self.set_window_mode(True)
        else:
            self.set_window_mode(False)
            
        self.context = mgl.create_context()

        self.context.enable(flags=mgl.DEPTH_TEST | mgl.CULL_FACE | mgl.BLEND)
        self.context.gc_mode = 'auto'

        self.clock = pg.time.Clock()
        self.delta_time = 0
        self.time = 0
        self.is_running = True
        self.on_init()

        if LOCK_MOUSE:
            pg.event.set_grab(True)
            pg.mouse.set_visible(False)

    def set_window_mode(self, condition):
        if condition == True:
            self.window = pg.display.set_mode((0,0), flags=pg.OPENGL | pg.DOUBLEBUF | pg.FULLSCREEN)
        elif condition == pg.WINDOWMAXIMIZED:
            self.window = pg.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), flags=pg.OPENGL |  pg.DOUBLEBUF | pg.RESIZABLE)
        elif condition == pg.WINDOWRESTORED:
            self.window = pg.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), flags=pg.OPENGL |  pg.DOUBLEBUF | pg.RESIZABLE)
        elif condition == False:
            self.window = pg.display.set_mode(WIN_RES, flags=pg.OPENGL | pg.DOUBLEBUF | pg.RESIZABLE)

    def on_init(self):
        self.textures = Textures(self)
        self.player = player(self)
        self.shader_manager = shader_manager(self, "chunk")
        self.scene = scene(self)

    def update(self):
        self.player.update()
        self.shader_manager.update()
        self.scene.update()
        
        self.delta_time = self.clock.tick()
        self.time = pg.time.get_ticks() * 0.001
        pg.display.set_caption(f'{self.clock.get_fps() :.0f}')

    def render(self):
        self.context.clear(color=BACKGROUND_COLOR)

        self.scene.render()
        pg.display.flip()

    def handle_events(self):
        for event in pg.event.get():
            self.player.handle_event(event=event)
            if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
                self.is_running = False

            elif event.type == pg.KEYDOWN and event.key == pg.K_F11:
                if self.fullscreen:
                    self.fullscreen = False
                    self.set_window_mode(False)
                else:
                    self.fullscreen = True
                    self.set_window_mode(True)

            elif event.type == pg.WINDOWMAXIMIZED:
                    self.set_window_mode(pg.WINDOWMAXIMIZED)
            elif event.type == pg.WINDOWRESTORED:
                    self.set_window_mode(pg.WINDOWRESTORED)


    def run(self):
        while self.is_running:
            self.handle_events()
            self.update()
            self.render()
        pg.quit()
        sys.exit()

if __name__ == "__main__":
    app = ToutchEngine()
    app.run()