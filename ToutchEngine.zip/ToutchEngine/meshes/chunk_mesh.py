from meshes.default_mesh import mesh
from meshes.chunk_mesh_builder import create_chunk_mesh

class chunk_mesh(mesh):
    def __init__(self, chunk):
        super().__init__()
        self.app = chunk.app
        self.chunk = chunk
        self.context = self.app.context
        self.manager = self.app.shader_manager.chunk

        self.vbo_format = '1u4'
        self.format_size = sum(int(fmt[:1]) for fmt in self.vbo_format.split())
        self.attrs = ('packed_data',)
        self.vao = self.get_vao()

    def rebuild(self):
        self.vao = self.get_vao()

    def get_vertex_data(self):
        mesh = create_chunk_mesh(
            chunk_voxels= self.chunk.voxels,
            format_size = self.format_size,
            chunk_position = self.chunk.position,
            world_voxels = self.chunk.world.voxels
        )
        return mesh