import numpy as np

class mesh:
    def __init__(self):
        #openGL
        self.context = None
        #shader manager
        self.manager = None
        #vertex buffer data type format: "3f 3f"
        self.vbo_format = None
        #mesh atributes:
        self.attrs: tuple[str, ...] = None
        #vertex array objects
        self.vao = None

    def get_vertex_data(self) -> np.array: ...

    def get_vao(self):
        vertex_data = self.get_vertex_data()
        vbo = self.context.buffer(vertex_data)
        vao = self.context.vertex_array(
            self.manager, [(vbo, self.vbo_format, *self.attrs)], skip_errors = True
        )
        return vao

    def render(self):
        self.vao.render()