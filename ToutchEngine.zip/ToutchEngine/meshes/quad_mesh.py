from meshes.default_mesh import mesh
from game.config import *

class QuadMesh(mesh):
    def __init__(self, app):
        super().__init__()

        self.app = app
        self.context = app.context
        self.manager = app.shader_manager.quad

        self.vbo_format = '3f 3f'
        self.attrs = ('in_position', 'in_color')
        self.vao = self.get_vao()

    def get_vertex_data(self):
        vertices = [
            (0.25, 0.25, 0.0), (-0.25, 0.25, 0.0), (-0.25, -0.25, 0.0),
            (0.25, 0.25, 0.0), (-0.25, -0.25, 0.0), (0.25, -0.25, 0.0)
        ]
        colors = [
            (0, 1, 0), (1, 0, 0), (0, 0, 1), 
            (0, 1, 0), (0, 0, 1), (0, 1, 0), 
        ]
        vertex_data = np.hstack([vertices, colors], dtype='float32')
        return vertex_data