from game.config import *

class shader_manager:
    def __init__(self, app, shaders):
        self.app = app
        self.context = app.context
        self.player = app.player
        
        #shaders
        self.chunk = self.get_shader(shader=shaders)
        self.voxel_pointer = self.get_shader(shader='voxel_pointer')
        #self.obj = self.get_shader(shader='obj_model')
        self.set_uniforms_on_init()

    def set_uniforms_on_init(self):
        self.chunk['m_proj'].write(self.player.m_proj)
        self.chunk['m_model'].write(glm.mat4())
        self.chunk['u_sprite_sheet_0'] = 1
        self.chunk['background_color'].value = (BACKGROUND_COLOR)

        self.voxel_pointer['m_proj'].write(self.player.m_proj)
        self.voxel_pointer['m_model'].write(glm.mat4())
        self.voxel_pointer['u_texture_0'] = 0

        #self.obj['m_proj'].write(self.player.m_proj)
        #self.obj['m_model'].write(glm.mat4())
        #self.obj['u_texture_0'] = 0

    def update(self):
        self.chunk['m_view'].write(self.player.m_view)
        self.voxel_pointer['m_view'].write(self.player.m_view)
        #self.obj['m_view'].write(self.player.m_view)

    def get_shader(self, shader):
        with open(f'shaders/{shader}.vert') as file:
            vertex_shader = file.read()
        with open(f'shaders/{shader}.frag') as file:
            fragment_shader = file.read()

        manager = self.context.program(vertex_shader=vertex_shader, fragment_shader=fragment_shader)
        return manager