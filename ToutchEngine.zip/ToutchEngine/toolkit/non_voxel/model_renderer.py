import numpy as np
import moderngl as mgl
import pywavefront as pwf
from meshes.default_mesh import mesh
from shader_manager import shader_manager

class obj_model(mesh):
    def __init__(self, obj_file, app):
        super().__init__()

        self.app = app
        self.context = app.context
        self.manager = app.shader_manager.obj  # Usando o shader 'obj' do shader_manager

        self.vbo_format = '3f 3f'  # Posição e cor
        self.attrs = ('in_position', 'in_color')
        self.vao = self.get_vao()

        # Carregar o arquivo .obj
        self.obj = pwf.Wavefront(obj_file, collect_faces=True)

    def get_vertex_data(self):
        vertices = []
        colors = []

        # Iterar sobre as faces do objeto
        for mesh in self.obj.mesh_list:
            for face in mesh.faces:
                for vertex_index in face:
                    vertex = self.obj.vertices[vertex_index]
                    vertices.append(vertex)

                    # Adicionar uma cor fixa para cada vértice (por exemplo, branco)
                    colors.append((1.0, 1.0, 1.0))  # Cor branca

        # Converter listas para arrays numpy
        vertices = np.array(vertices, dtype='float32')
        colors = np.array(colors, dtype='float32')

        # Combinar vértices e cores em um único array
        vertex_data = np.hstack([vertices, colors])
        return vertex_data

    def render(self):
        self.vao.render()