import pygame as pg
import moderngl as mgl

def load(app, file_name, is_sprite_sheet=False):
    texture = pg.image.load(f'assets/{file_name}')
    texture = pg.transform.flip(texture, flip_x=True, flip_y=False)

    if is_sprite_sheet:
        num_layers = 3 * texture.get_height() // texture.get_width() # 3 textures per layer
        texture = app.context.texture_array(
            size=(texture.get_width(), texture.get_height() // num_layers, num_layers),
            components=4,
            data=pg.image.tostring(texture, 'RGBA')
        )

        texture.filter = (mgl.NEAREST, mgl.NEAREST)
    else:
        texture = app.context.texture(
            size=texture.get_size(),
            components=4,
            data=pg.image.tostring(texture, 'RGBA', False)
        )
    texture.anisotropy = 32.0
    texture.build_mipmaps()
    texture.filter = (mgl.NEAREST, mgl.NEAREST)
    return texture